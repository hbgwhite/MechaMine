package com.hbgwhite;

import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_9886;

public class BoomSword extends class_1792 {

    public BoomSword() {
        super(class_9886.field_52588.method_61662(
            new class_1792.class_1793().method_63686(MechaMine.BOOM_SWORD_KEY), 
            96.0f, -2.4f));
    }

    @Override
    public void method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (attacker instanceof class_1657 player && attacker.method_73183() instanceof class_3218 serverWorld) {
            class_243 look = player.method_5828(1.0f);

            class_1541 tnt = new class_1541(serverWorld,
                player.method_23317() + look.field_1352 * 2,
                player.method_23320(),
                player.method_23321() + look.field_1350 * 2,
                null);

            tnt.method_18800(look.field_1352 * 2, look.field_1351 * 0.5 + 0.3, look.field_1350 * 2);
            serverWorld.method_8649(tnt);
        }
        super.method_7873(stack, target, attacker);
    }
}