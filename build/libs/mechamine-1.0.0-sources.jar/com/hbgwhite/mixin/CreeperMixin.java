package com.hbgwhite.mixin;

import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1548;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1548.class)
public class CreeperMixin {

    @Inject(at = @At("HEAD"), method = "explode", cancellable = true)
    private void onExplode(CallbackInfo info) {
        class_1548 creeper = (class_1548)(Object)this;

        if (creeper.method_73183() instanceof class_3218 serverWorld) {
            info.cancel();

            serverWorld.method_8437(
                creeper,
                creeper.method_23317(), creeper.method_23318(), creeper.method_23321(),
                9.0f,
                class_1937.class_7867.field_40890
            );

            class_1538 lightning = new class_1538(
                class_1299.field_6112, serverWorld
            );
            lightning.method_24203(
                creeper.method_23317(), creeper.method_23318(), creeper.method_23321()
            );
            serverWorld.method_8649(lightning);
        }
    }
}