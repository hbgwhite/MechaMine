package com.hbgwhite.mixin.client;

import net.minecraft.class_2960;
import net.minecraft.class_887;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_887.class)
public class CreeperRendererMixin {

    @Inject(at = @At("HEAD"), method = "getTexture", cancellable = true)
    private void overrideTexture(CallbackInfoReturnable<class_2960> info) {
        info.setReturnValue(class_2960.method_60655("mecha-mine", "textures/entity/creeper/creeper.png"));
    }
}