package com.hbgwhite;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MechaMine implements ModInitializer {
	public static final String MOD_ID = "mechamine";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final class_5321<class_1792> BOOM_SWORD_KEY = class_5321.method_29179(
		class_7923.field_41178.method_46765(),
		class_2960.method_60655(MOD_ID, "boom_sword")
	);

	public static final BoomSword BOOM_SWORD = new BoomSword();

	@Override
	public void onInitialize() {
		LOGGER.info("MechaMine loaded!");
		class_2378.method_39197(class_7923.field_41178, BOOM_SWORD_KEY, BOOM_SWORD);
	}
}